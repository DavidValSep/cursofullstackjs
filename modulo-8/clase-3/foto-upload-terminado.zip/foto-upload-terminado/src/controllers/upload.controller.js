export const uploadPhoto = (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No se proporcionó ningún archivo" });
  }

  return res.status(201).json({
    message: "Archivo subido exitosamente",
    file: {
      originalName: req.file.originalname,
      route: req.file.path,
      size: req.file.size,
      mimeType: req.file.mimetype,
    },
  });
};
